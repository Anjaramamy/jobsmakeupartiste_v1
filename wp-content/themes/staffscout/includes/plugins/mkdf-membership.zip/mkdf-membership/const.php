<?php

define( 'MIKADO_MEMBERSHIP_VERSION', '1.0' );
define( 'MIKADO_MEMBERSHIP_ABS_PATH', dirname( __FILE__ ) );
define( 'MIKADO_MEMBERSHIP_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'MIKADO_MEMBERSHIP_SHORTCODES_PATH', MIKADO_MEMBERSHIP_ABS_PATH . '/shortcodes' );