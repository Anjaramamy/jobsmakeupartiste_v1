<div class="mkdf-rs-item-title">
	<h2 class="mkdf-rs-item-title-inner">
		<?php echo get_the_title(); ?>
	</h2>
</div>