<div class="mkdf-membership-dashboard-page">
	<div class="mkdf-membership-dashboard-page-content">
		<?php
			echo staffscout_mikado_execute_shortcode('submit_resume_form', '');
		?>
	</div>
</div>