<?php

global $job_manager_bookmarks;

?>

<div class="mkdf-rs-login-info">
    <div class="mkdf-rs-login-info-inner">
        <?php do_action( 'single_resume_start', array( $job_manager_bookmarks, 'bookmark_form' ) ); ?>
    </div>
</div>