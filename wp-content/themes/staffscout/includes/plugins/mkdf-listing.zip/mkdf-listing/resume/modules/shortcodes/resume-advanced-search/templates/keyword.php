<div class="mkdf-rs-adv-search-keyword-holder">
    <?php echo staffscout_mikado_icon_collections()->renderIcon('dripicons-document', 'dripicons'); ?>
    <input type="text" class="mkdf-rs-adv-search-keyword" name="mkdf-rs-adv-search-keyword"
           placeholder="<?php esc_html_e('All Resumes', 'mkdf-listing'); ?>">
</div>