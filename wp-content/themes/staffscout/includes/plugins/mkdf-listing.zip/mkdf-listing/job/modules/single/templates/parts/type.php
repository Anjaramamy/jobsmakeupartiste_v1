<?php

print $article_obj->getTaxHtml('job_listing_type', 'mkdf-listing-type-wrapper');