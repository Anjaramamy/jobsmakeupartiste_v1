<div class="mkdf-ls-item-title">
	<h2 class="mkdf-ls-item-title-inner">
		<?php echo get_the_title(); ?>
	</h2>
</div>