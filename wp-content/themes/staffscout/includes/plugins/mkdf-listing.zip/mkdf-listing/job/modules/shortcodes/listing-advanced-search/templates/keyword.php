<div class="mkdf-ls-adv-search-keyword-holder">
    <?php echo staffscout_mikado_icon_collections()->renderIcon('dripicons-document-edit', 'dripicons'); ?>
    <input type="text" class="mkdf-ls-adv-search-keyword" name="mkdf-ls-adv-search-keyword"
           placeholder="<?php esc_html_e('Keywords', 'mkdf-listing'); ?>">
</div>