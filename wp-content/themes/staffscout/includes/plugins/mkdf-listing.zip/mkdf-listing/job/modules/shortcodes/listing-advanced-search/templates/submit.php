<div class="mkdf-ls-adv-search-submit-button">
    <?php echo staffscout_mikado_get_button_html(array(
        'text' => esc_html__('Search', 'mkdf-listing'),
        'html_type' => 'button',
        'type' => 'solid',
        'size'  => 'medium',
        'fullwidth' => 'yes',
        'custom_class' => 'mkdf-ls-adv-search-keyword-button'
    )); ?>
</div>