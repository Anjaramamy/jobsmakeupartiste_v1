<div class="mkdf-ls-item mkdf-item-space clearfix">
    <div class="mkdf-ls-inner">
        <a href="<?php echo get_the_permalink(); ?>" class="mkdf-ls-item-author-image">
            <?php echo get_avatar(get_the_author_meta('ID'), 88 ); ?>
        </a>
    </div>
</div>