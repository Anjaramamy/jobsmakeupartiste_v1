<div class="mkdf-ls-item-title">
    <h6 class="mkdf-ls-item-title-inner">
        <?php echo get_the_title(); ?>
    </h6>
</div>