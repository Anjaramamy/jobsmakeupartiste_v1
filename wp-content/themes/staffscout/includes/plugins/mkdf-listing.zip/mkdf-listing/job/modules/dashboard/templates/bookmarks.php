<div class="mkdf-membership-dashboard-page">
    <div class="mkdf-membership-dashboard-page-content">
        <?php
        echo staffscout_mikado_execute_shortcode('my_bookmarks', '');
        ?>
    </div>
</div>