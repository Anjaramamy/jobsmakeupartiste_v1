<?php

global $job_manager_bookmarks;

?>

<div class="mkdf-ls-login-info">
    <div class="mkdf-ls-login-info-inner">
        <?php do_action( 'single_resume_start', array( $job_manager_bookmarks, 'bookmark_form' ) ); ?>
    </div>
</div>