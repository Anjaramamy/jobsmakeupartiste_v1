<li class="mkdf-tab-slider-item" data-dot="<p><?php echo esc_attr($slide_title); ?></p>">
    <div class="mkdf-tab-slide-holder">
        <?php echo mkdf_core_get_shortcode_module_template_part('templates/slide-content', 'tab-slider', '', array('content' => $content)); ?>
    </div>
</li>
