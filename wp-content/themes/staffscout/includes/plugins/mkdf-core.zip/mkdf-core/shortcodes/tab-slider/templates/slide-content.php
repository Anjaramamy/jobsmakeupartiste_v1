<div class="mkdf-tab-slide-content">
    <?php echo staffscout_mikado_remove_auto_ptag($content, true); ?>
</div>
