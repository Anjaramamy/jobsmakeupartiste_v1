<div class="mkdf-workflow <?php echo esc_attr($el_class) ?>">
    <span class="main-line" style="<?php echo esc_attr($main_line_style); ?>"></span>
    <?php echo do_shortcode($content) ?>
</div>