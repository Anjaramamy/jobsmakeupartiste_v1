<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/tab-slider/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/tab-slider/tab-slider.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/tab-slider/tab-slider-item.php';
