<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/image-marquee/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/image-marquee/image-marquee.php';