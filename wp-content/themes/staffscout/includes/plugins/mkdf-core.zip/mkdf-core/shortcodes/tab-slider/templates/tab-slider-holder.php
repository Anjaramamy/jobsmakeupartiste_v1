<div class="mkdf-tab-slider-holder">
    <div class="mkdf-tab-slider-container">
        <ul class="mkdf-tab-slider-container-inner mkdf-owl-slider" <?php echo staffscout_mikado_get_inline_attrs($slider_data); ?>>
            <?php echo do_shortcode($content); ?>
        </ul>
    </div>
</div>