<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/comparison-pricing-tables/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/comparison-pricing-tables/cpt-holder.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/comparison-pricing-tables/cpt-table.php';